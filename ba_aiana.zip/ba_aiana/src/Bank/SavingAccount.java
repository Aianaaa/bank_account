package Bank;
public abstract class SavingAccount extends BankAccount {
    private double interestRate;

    public SavingAccount(int accountNumber, double balance, String customerName, String email, String phoneNumber, String username, String password, CurrencyConverter converter, double interestRate) {
        super(accountNumber, balance, customerName, email, phoneNumber, username, password, converter);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public abstract boolean login(String username, String password);
}