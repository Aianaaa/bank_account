package Bank;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(12345, 1000, "John Doe", "john@doe.com", "1234567890",
                "ayana", "password", new CurrencyConverter(70.0));
        BankAccount account1 = new BankAccount("upol", 1234);
        Bill bill = new Bill(100, "11/01");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = sc.next();
        System.out.print("Enter password: ");
        String password = sc.next();
        if (account.login(username, password)) {
            while (true) {
                System.out.println("\nWelcome to Bank Account System");
                System.out.println("1. Check Balance");
                System.out.println("2. Pay Bill");
                System.out.println("3. Convert money");
                System.out.println("4. Withdraw");
                System.out.println("5. Deposit");
                System.out.println("6. Transfer money");
                System.out.println("7. Exit");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();
                switch (choice) {
                    case 1:
                        account.checkBalance();
                        break;
                    case 2:
                        account.payBill(bill);
                        break;
                    case 3:
                        System.out.print("FROM: ");
                        String from = sc.next();
                        System.out.print("TO: ");
                        String to = sc.next();
                        System.out.print("How much do you want to convert: ");
                        int money = sc.nextInt();
                        CurrencyConverter currency = new CurrencyConverter(4.42);
                        System.out.println(currency.convert(money, from, to));
                        if (currency.convert(money, from, to) == -1) {
                            System.out.println("Sorry, we can't convert this currency!");
                        }
                        break;
                    case 4:
                        System.out.print("How much do you want to withdraw: ");
                        int money1 = sc.nextInt();
                        account.withdraw(money1);
                        break;
                    case 5:
                        System.out.print("How much do you want to deposit: ");
                        int money2 = sc.nextInt();
                        account.deposit(money2);
                        break;
                    case 6:
                        System.out.print("Whom do you want to transfer: ");
                        String name = sc.next();
                        System.out.print("Enter bank number: ");
                        int number = sc.nextInt();
                        System.out.print("How much do you want to transfer: ");
                        int money3 = sc.nextInt();
                        BankAccount ba = new BankAccount(name, number);
                        System.out.println("Your balance before the transition: " + account.getBalance());
                        account.transfer(ba, money3);
                        System.out.println("Your balance after the transition: " + account.getBalance());
                        break;
                    case 7:
                        System.out.println("Thank you for using the Bank Account System.");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }
    }
}
