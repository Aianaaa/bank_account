package Bank;

public class CurrencyConverter {
    private double exchangeRate;

    public CurrencyConverter(double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public double getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public double convert(double amount, String fromCurrency, String toCurrency) {
        if (fromCurrency.equals("USD") && toCurrency.equals("PLN")) {
            return amount * exchangeRate;
        } else if (fromCurrency.equals("PLN") && toCurrency.equals("USD")) {
            return amount / exchangeRate;
        } else {
            return -1;
        }
    }
}
