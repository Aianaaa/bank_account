package Bank;

public class Bill {
    private double amount;
    private String dueDate;

    public Bill(double amount, String dueDate) {
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
}

