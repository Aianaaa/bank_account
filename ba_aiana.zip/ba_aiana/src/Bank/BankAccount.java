package Bank;
public class BankAccount {
    private int accountNumber;
    private double balance;
    private String customerName;
    private String email;
    private String phoneNumber;
    private String username;
    private String password;
    private CurrencyConverter converter;
    public BankAccount(String name, int number)
    {
        this.customerName = name;
        this.accountNumber = number;
    }

    public BankAccount(int accountNumber, double balance, String customerName, String email, String phoneNumber, String username, String password, CurrencyConverter converter) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.customerName = customerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
        this.converter = converter;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public CurrencyConverter getConverter() {
        return converter;
    }

    public void setConverter(CurrencyConverter converter) {
        this.converter = converter;
    }

    public boolean login(String username, String password)
    {
        if (username.equals(getUsername()) && password.equals(getPassword())) {
            System.out.println("Login successful.");
            return true;
        } else {
            System.out.println("Login failed.");
            return false;
        }
    }

    public void deposit(double amount) {
        if (login(username, password)) {
            this.balance += amount;
            System.out.println("Deposit successful. Your new balance is " + this.balance);
        }
    }

    public void withdraw(double amount) {
        if (login(username, password)) {
            if (this.balance >= amount) {
                this.balance -= amount;
                System.out.println("Withdrawal successful. Your new balance is " + this.balance);
            } else {
                System.out.println("Insufficient funds.");
            }
        }
    }

    public void checkBalance() {
        if (login(username, password)) {
            System.out.println("Your balance is " + this.balance);
        }
    }


    public void transfer(BankAccount ba, int amount) {
        if (login(username, password)) {
            if (this.balance >= amount) {
                this.balance -= amount;
                System.out.println("Transfer successful. Your new balance is " + this.balance);
            } else {
                System.out.println("Insufficient funds.");
            }
        }
    }

    public void payBill(Bill bill) {
        if (this.balance >= bill.getAmount()) {
            this.balance -= bill.getAmount();
            System.out.println("Successfully paid bill of amount: " + bill.getAmount());
        } else {
            System.out.println("Insufficient balance to pay bill.");
        }
    }

}